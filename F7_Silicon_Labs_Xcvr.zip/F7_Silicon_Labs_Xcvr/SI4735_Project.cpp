#include <SI4735.h>
#include "si5351.h"
#include "patch_full.h"    // SSB patch for whole SSBRX full download
#include "SI4735_Project.h"

#define FT8_TONE_SPACING        625          // ~6.25 Hz

#define PTT_Pin 13

const uint16_t size_content = sizeof ssb_patch_content; // see ssb_patch_content in patch_full.h or patch_init.h

extern char S_Input[16];
unsigned long T_Freq;
uint64_t F_Long, F_FT8, F_Offset;

extern SI4735 si4735;
extern Si5351 si5351;
extern uint16_t currentFrequency;
uint16_t cursor_freq;
//char ft8_tone;

int bfo_frequency;

void loadSSB()
{
  si4735.queryLibraryId(); // Is it really necessary here? I will check it.
  si4735.patchPowerUp();
  delay(50);
  si4735.downloadPatch(ssb_patch_content, size_content);
  // Parameters
  // AUDIOBW - SSB Audio bandwidth; 0 = 1.2KHz (default); 1=2.2KHz; 2=3KHz; 3=4KHz; 4=500Hz; 5=1KHz;
  // SBCUTFLT SSB - side band cutoff filter for band passand low pass filter ( 0 or 1)
  // AVC_DIVIDER  - set 0 for SSB mode; set 3 for SYNC mode.
  // AVCEN - SSB Automatic Volume Control (AVC) enable; 0=disable; 1=enable (default).
  // SMUTESEL - SSB Soft-mute Based on RSSI or SNR (0 or 1).
  // DSP_AFCDIS - DSP AFC Disable or enable; 0=SYNC MODE, AFC enable; 1=SSB MODE, AFC disable.
  //si4735.setSSBConfig(bandwidthIdx, 1, 0, 1, 0, 1);
  si4735.setSSBConfig(2, 1, 0, 1, 0, 1);  //2 = 3 kc bandwidth
}





void Command_P(void){
unsigned long T_Freq;
int n;
char c;

 
switch (S_Input[0]){

  case 'F': case 'f':  //set receiver frequency
      T_Freq = Conv_Freq();
      Serial.println ("Receive");
      Serial.println (T_Freq);
      si4735.setFrequency(T_Freq );
      //si4735.setFrequency(10000);
      delay(10);
      currentFrequency = si4735.getFrequency();
      Serial.println (currentFrequency);
  break;

  case 'B': case 'b':  //set base frequency for FT8 tone transmit
      T_Freq = Conv_Freq();
      Serial.println ("TuneBase");
      Serial.println (T_Freq);
      //F_Long = uint64_t(T_Freq) * 100;
      //F_Long = F_Long + F_Offset;
      cursor_freq = (uint16_t)T_Freq;
      set_Xmit_Freq();
     // F_Long = (uint64_t) ((currentFrequency * 1000 + cursor_freq) * 100);
     // si5351.set_freq(F_Long, SI5351_CLK0);
  break;

  case 'T': case 't':  //set FT8 tone
    T_Freq = Conv_Freq();
    F_FT8 =  F_Long + uint64_t(T_Freq) * FT8_TONE_SPACING;
    si5351.set_freq(F_FT8, SI5351_CLK0);
  break;

  case 'R': case 'r':  //set frequency offset so receive and xmit frequenct match
      //int bfo_frequency;
      T_Freq = Conv_Freq();
      bfo_frequency =   (int)T_Freq - 10000;
      Serial.println ("BFO Freq");
      Serial.println (bfo_frequency);
     // si4735.setSSBBfo(bfo_frequency );
      //F_Offset = bfo_frequency * 1000;
     // si5351.set_freq(F_Long + F_Offset, SI5351_CLK0); 
     set_Xmit_Freq(); 
    break;

  case 'C': case 'c':  //set si5351 correction so receive zero beats with wwv
      int correction;
      T_Freq = Conv_Freq();
      correction =  ( (int)T_Freq - 10000) * 100;
      Serial.println ("5351_Correction");
      Serial.println (correction);
      si5351.set_correction((int32_t) correction, SI5351_PLL_INPUT_XO);
      si5351.set_pll(SI5351_PLL_FIXED, SI5351_PLLA);
    break;

  case 'X': case 'x':
    if (S_Input[1] == '0'){
       Serial.println ("Receive");
       si5351.output_enable(SI5351_CLK0, 0); 
       digitalWrite(PTT_Pin, LOW);   
   }
    if (S_Input[1] == '1'){
       Serial.println ("Xmit");
       set_Xmit_Freq();
       //si5351.set_freq(10000000*100, SI5351_CLK0);
       si5351.output_enable(SI5351_CLK0, 1);
       digitalWrite(PTT_Pin, HIGH);    
    }
 

     if (S_Input[1] == '2'){
     Serial.println ("Tune On");
     set_Xmit_Freq();
     //si5351.set_freq(10000000*100, SI5351_CLK0);
     si5351.output_enable(SI5351_CLK0, 1);
     //digitalWrite(PTT_Pin, HIGH);    
    }
 

    if (S_Input[1] == '3'){
    Serial.println ("Tune Off");
    si5351.output_enable(SI5351_CLK0, 0);  
    //digitalWrite(PTT_Pin, LOW);    
    }
    
    break;
  
  }  
} 

void  set_Xmit_Freq(){
      F_Long = (uint64_t) ((currentFrequency * 1000 + cursor_freq + bfo_frequency) * 100);
      si5351.set_freq(F_Long, SI5351_CLK0);
}

unsigned long Conv_Freq(void){
unsigned long freq = 0, mult = 1;

  for(char i = 15; i > 0; i--){
    if (S_Input[i] > 47 && S_Input[i] < 58){
      freq += mult * (S_Input[i] - 48);  
      mult *= 10;
    }  
  }
 // Serial.print(freq);
  return freq;
}
